from tkinter import *
from PIL import ImageTk, Image

root=Tk()
root.title("Autentificación de tarjeta de crédito")
root.geometry("600x400")

root.configure(background="gold")

input_box = Entry()
input_box.place(relx=0.5, rely=0.3, anchor = CENTER)

img=ImageTk.PhotoImage(Image.open ("credit.jpg"))
label = Label(root, image=img)


def authentication():
    try:
        input_value = int(input_box.get())
        messagebox.showinfo("mensaje","Se acepta la tarjeta de crédito")
    except(ValueError):
        messagebox.showinfo("Alerta","No se acepta la tarjeta de crédito. Por favor, introduzca un código PIN válido")

btn = Button(root, text = "comprobar la tarjeta de crédito", command = authentication)
btn.place(relx=0.5, rely=0.4, anchor = CENTER)
label.place(relx=0.5, rely=0.7, anchor = CENTER)

root.mainloop()